<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Mapel extends Model
{
    protected $fillable = ['id_guru', 'nama_mapel'];
}
