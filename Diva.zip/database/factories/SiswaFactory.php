<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Siswa;
use Faker\Generator as Faker;

$factory->define(Siswa::class, function (Faker $faker) {
    return [
        //
    ];
});
