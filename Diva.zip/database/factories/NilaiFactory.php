<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Nilai;
use Faker\Generator as Faker;

$factory->define(Nilai::class, function (Faker $faker) {
    return [
        //
    ];
});
