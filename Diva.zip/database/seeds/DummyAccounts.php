<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DummyAccounts extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'username' => 'divaAzzahra',
            'password' => bcrypt('1234'),
            'level' => 1,
        ]);
    }
}
